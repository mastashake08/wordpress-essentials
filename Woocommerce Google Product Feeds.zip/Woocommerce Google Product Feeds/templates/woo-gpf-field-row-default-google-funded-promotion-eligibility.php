<select name="_woocommerce_gpf_data[{key}]" class="woocommerce-gpf-store-default">
	<option value="all" {all-selected}><?php _e( 'Eligible for ALL Google funded promotions', 'woocommerce_gpf' ); ?></option>
	<option value="none" {none-selected}><?php _e( 'Excluded from Google funded promotions', 'woocommerce_gpf' ); ?></option>
</select>
