<div class="woocommerce_gpf_config_{key}">
	{defaultinput}
</div>
