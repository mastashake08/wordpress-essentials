<div class="woocommerce_gpf_config_{key} woocommerce-gpf-store-default" {displaynone}>
	<p>
		{defaultinput}
	</p>
	{prepopulates}
</div>
