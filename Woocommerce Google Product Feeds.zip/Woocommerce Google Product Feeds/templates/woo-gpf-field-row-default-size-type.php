<select name="_woocommerce_gpf_data[{key}]" class="woocommerce-gpf-store-default">
	<option value="">{emptytext}</option>
	<option value="regular" {regular-selected}><?php _e( 'Regular', 'woocommerce_gpf' ); ?></option>
	<option value="petite" {petite-selected}><?php _e( 'Petite', 'woocommerce_gpf' ); ?></option>
	<option value="plus" {plus-selected}><?php _e( 'Plus', 'woocommerce_gpf' ); ?></option>
	<option value="big and tall" {big and tall-selected}><?php _e( 'Big and Tall', 'woocommerce_gpf' ); ?></option>
	<option value="maternity" {maternity-selected}><?php _e( 'Maternity', 'woocommerce_gpf' ); ?></option>
</select>