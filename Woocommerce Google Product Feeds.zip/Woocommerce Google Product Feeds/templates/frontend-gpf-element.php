<div class="woocommerce-gpf-element">
	<span class="woocommerce-gpf-element-value">
		{values}
	</span>
</div>
