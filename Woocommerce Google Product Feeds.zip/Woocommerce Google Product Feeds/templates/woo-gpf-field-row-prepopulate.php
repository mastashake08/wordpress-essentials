<p>
	{intro_text}<br>
	<select name="_woocommerce_gpf_prepopulate[{key}]" class="woocommerce-gpf-prepopulate">
		{options}
	</select>
</p>
