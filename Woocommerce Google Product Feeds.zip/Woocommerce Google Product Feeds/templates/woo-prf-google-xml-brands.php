                		<brands>
{brands}
	                	</brands>