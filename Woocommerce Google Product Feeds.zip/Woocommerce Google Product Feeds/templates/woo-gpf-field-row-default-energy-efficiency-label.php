	<select name="_woocommerce_gpf_data[{key}]" class="woocommerce-gpf-store-default">
		<option value="">{emptytext}</option>
		<option value="A+++" {A+++-selected}><?php _e( 'A+++', 'woocommerce_gpf' ); ?></option>
		<option value="A++" {A++-selected}><?php _e( 'A++', 'woocommerce_gpf' ); ?></option>
		<option value="A+" {A+-selected}><?php _e( 'A+', 'woocommerce_gpf' ); ?></option>
		<option value="A" {A-selected}><?php _e( 'A', 'woocommerce_gpf' ); ?></option>
		<option value="B" {B-selected}><?php _e( 'B', 'woocommerce_gpf' ); ?></option>
		<option value="C" {C-selected}><?php _e( 'C', 'woocommerce_gpf' ); ?></option>
		<option value="D" {D-selected}><?php _e( 'D', 'woocommerce_gpf' ); ?></option>
		<option value="E" {E-selected}><?php _e( 'E', 'woocommerce_gpf' ); ?></option>
		<option value="F" {F-selected}><?php _e( 'F', 'woocommerce_gpf' ); ?></option>
		<option value="G" {G-selected}><?php _e( 'G', 'woocommerce_gpf' ); ?></option>
	</select>
