<hr>
<h3><?php _e( 'Feed fields to enable', 'woocommerce_gpf' ); ?></h3>
<p><?php _e( 'Choose which fields you want in your feed for each product, and set store-wide defaults below where necessary: ', 'woocommerce_gpf' ); ?><br/></p>
<table class="form-table">
