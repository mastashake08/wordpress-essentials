 <p>
        <input type="checkbox" name="_woocommerce_gpf_enabled_feeds[{feed_id}]" {checked}> {html_name}
        <span class="{url_hidden}">
		    (<a href="{attr_url}">{html_url}</a>)
	    </span>
 </p>