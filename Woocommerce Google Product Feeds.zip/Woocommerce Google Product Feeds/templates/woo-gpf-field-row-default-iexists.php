<select name="_woocommerce_gpf_data[{key}]" class="woocommerce-gpf-store-default">
	<option value="">{emptytext}</option>
	<option value="included" {included-selected}><?php _e( 'Included', 'woocommerce_gpf' ); ?></option>
	<option value="not-included" {not-included-selected}><?php _e( 'Not included', 'woocommerce_gpf' ); ?></option>
</select>
