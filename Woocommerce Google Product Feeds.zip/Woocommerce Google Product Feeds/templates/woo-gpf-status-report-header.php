<table class="wc_status_table widefat" cellspacing="0">
    <thead>
    <tr>
        <th colspan="3" data-export-label="{attr_title}"><h2>{title}</h2></th>
    </tr>
    </thead>
    <tbody>
