<?php echo '<?xml'; ?> version='1.0' encoding='UTF-8' ?>
<feed xmlns:vc="http://www.w3.org/2007/XMLSchema-versioning"
	  xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	  xsi:noNamespaceSchemaLocation="http://www.google.com/shopping/reviews/schema/product/2.1/product_reviews.xsd">
    <version>2.2</version>
	<aggregator>
		<name>WooCommerce Product Feeds v{version} by Ademti Software - https://woocommerce.com/products/google-product-feed</name>
	</aggregator>
	<publisher>
		<name>{store_name}</name>
	</publisher>
	<reviews>
